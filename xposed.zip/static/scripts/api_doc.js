function jsfunction() {
    new SpiderController({});
}